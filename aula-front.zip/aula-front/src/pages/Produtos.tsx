import React from 'react';

const Produtos = () => {
  return (
    <div>
      <h1>Produtos</h1>
      <p>Confira nossa seleção de móveis e suprimentos para escritório.</p>
    </div>
  );
};

export default Produtos;

