
const Carrinho = () => {
  return (
    <div>
      <h1>Carrinho de Compras</h1>
      <p>Seu carrinho está vazio no momento. Explore nossos produtos e adicione itens ao carrinho.</p>
    </div>
  );
};

export default Carrinho;
