import React from 'react';

const Servicos = () => {
  return (
    <div>
      <h1>Serviços</h1>
      <p>Oferecemos consultoria, montagem e entrega especializada para seu ambiente de trabalho.</p>
    </div>
  );
};

export default Servicos;

