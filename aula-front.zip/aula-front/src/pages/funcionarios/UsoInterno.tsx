const UsoInterno = () => {
    return (
      <div>
        <h1>Área do funcionário</h1>
        <p>Olá Funcionário, aqui você terá acesso a ferramentas de uso intern.  </p>
      </div>
    );
  };
  
  export default UsoInterno;