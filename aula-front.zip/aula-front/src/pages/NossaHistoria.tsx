import React from 'react';

const NossaHistoria = () => {
  return (
    <div>
      <h1>Nossa História</h1>
      <p>A R. Amaral Office nasceu com o propósito de transformar ambientes de trabalho em espaços mais funcionais e inspiradores.</p>
    </div>
    
  );
};

export default NossaHistoria;

