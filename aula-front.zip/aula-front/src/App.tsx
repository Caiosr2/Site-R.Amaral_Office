import styled from "styled-components"
import { Button } from "@/components/ui/button"
import { useState } from 'react'
import './App.css'
import { IStyledComponent } from "styled-components"
import { Link } from "react-router-dom";
import Header from './Header';

const App = () => {
 <Header />
};

export default App;
