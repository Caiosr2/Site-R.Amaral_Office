export const config = { 
    apiBaseUrl: window.location.origin == 'http://localhost:5173' ? "http://localhost:8000" : "URL CRIADA NO DEPLOY"
  }

  